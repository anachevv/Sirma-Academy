function f(num) {
    return num % 2 === 0 ? "even" : "odd";
}

console.log(f(2));
console.log(f(3));
console.log(f(25));
console.log(f(1024));