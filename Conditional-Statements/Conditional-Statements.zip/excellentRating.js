function f(number) {
    if (number >= 5.5) {
        console.log("Excellent");
    }
}

f(5.5);
f(5.75);
f(4.95);