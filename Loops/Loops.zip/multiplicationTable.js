function f() {
    for (let i = 1; i < 11; i++) {
        for (let z = 1; z < 11; z++) {
            console.log(`${i} * ${z} = ${i * z}`);
        }
    }
}

f();