function f() {
    for (let i = 0; i < 101; i++) {
        console.log(i);
    }
}

f();
