function f(num) {
    for (i = num; i > -1; i--) {
        console.log(i);
    }
}

f(10);
f(5);