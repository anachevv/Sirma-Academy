function f(text) {
    for (let i = 0; i < text.length; i++) {
        console.log(text[i]);
    }
}

f("hello");
f("Bulgaria");