function f(n, m) {
    for (let i = 1; i < n + 1; i += m) {
        console.log(i);
    }
}

f(10, 2);
f(8, 3);
