function f(n) {
    for (i = 1; i < n + 1; i += 2) {
        console.log(i);
    }
}

f(10);
f(5);