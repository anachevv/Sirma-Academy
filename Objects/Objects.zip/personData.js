function getInfo(name, surname, age) {
    return {
        firstName: name,
        lastName: surname,
        age: age,
    };
}

console.log(getInfo('Ivan', 'Ivanov', 29));
console.log(getInfo("Maria", "Marinova", 13));
